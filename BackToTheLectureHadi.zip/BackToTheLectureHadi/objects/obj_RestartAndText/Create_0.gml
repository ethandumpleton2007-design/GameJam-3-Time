globalresetRoom = false
