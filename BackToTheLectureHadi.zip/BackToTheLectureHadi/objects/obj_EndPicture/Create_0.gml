visible = false
show = false