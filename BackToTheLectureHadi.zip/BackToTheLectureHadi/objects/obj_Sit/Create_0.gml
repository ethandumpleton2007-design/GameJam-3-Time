visible = false
show = true